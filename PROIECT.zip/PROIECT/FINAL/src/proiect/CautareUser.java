package proiect;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class CautareUser {

	private String url = "jdbc:mysql://localhost/proiect";
	private String user = "root";
	private String password = "17052002Da";
	private Connection con;

	JComboBox comboBox;
	JButton butonSend;
	JButton butonBack;
	JTextArea textArea;
	JTextArea textAreaMesaj;
	private JFrame frameMA;
	JTextField textField;
	JTextField textField_1;
	private JPanel panel;

	public CautareUser(String profil, String nume, String CNP) {
		connection();
		initialize(profil, nume, CNP);
	}

	private void initialize(String profil, String nume, String CNP) {
		frameMA = new JFrame();
		frameMA.getContentPane().setLayout(null);

		buttons(profil, nume, CNP);
		textFields(profil, nume, CNP);

		butonBack = new JButton("Back");
		butonBack.setFont(new Font("Tahoma", Font.PLAIN, 14));
		butonBack.setBounds(10, 405, 117, 45);
		butonBack.addActionListener(e -> {
			if (profil.equals("Student")) {
				frameMA.dispose();
				new DupaLoginS(profil, nume, CNP);
			} else if (profil.equals("Profesor")) {
				frameMA.dispose();
				new DupaLoginP(profil, nume, CNP);
			} else {
				frameMA.dispose();
				new DupaLoginA(profil, nume, CNP);
			}
		});
		frameMA.getContentPane().add(butonBack);

		textArea = new JTextArea();
		textArea.setEditable(false);
		JScrollPane sp = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sp.setBounds(10, 45, 464, 262);
		// frameMA.add(textArea);
		frameMA.add(sp);

		frameMA.getContentPane().add(sp);

		frameMA.setSize(500, 500);
		frameMA.setBounds(300, 300, 500, 500);
		frameMA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameMA.setVisible(true);
	}

	private void buttons(String profil, String nume, String CNP) {
		butonSend = new JButton("Afiseaza");
		butonSend.setFont(new Font("Tahoma", Font.PLAIN, 14));
		butonSend.setBounds(357, 405, 117, 45);
		butonSend.addActionListener(e -> {
			cautareUseri();

		});
		frameMA.getContentPane().add(butonSend);
	}

	private void textFields(String profil, String nume, String CNP) {

		JLabel label = new JLabel("Nume");
		label.setBounds(25, 320, 130, 35);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		frameMA.getContentPane().add(label);

		textField = new JTextField("");
		textField.setColumns(10);
		textField.setBounds(30, 360, 130, 35);
		frameMA.getContentPane().add(textField);

		JLabel label1 = new JLabel("Prenume");
		label1.setBounds(150, 320, 130, 35);
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		frameMA.getContentPane().add(label1);

		textField_1 = new JTextField("");
		textField_1.setColumns(10);
		textField_1.setBounds(175, 360, 130, 35);
		frameMA.getContentPane().add(textField_1);

	}

	private void connection() {
		try { // Load driver class
			Class.forName("com.mysql.jdbc.Driver");
		} catch (java.lang.ClassNotFoundException e) {
			System.err.println(e);
		}

		con = null;
		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex);
			System.exit(1);
		}
	}

	private void cautareUseri() {

		String[] tabela = new String[0];
		String[] det = new String[1000];
		try {
			Statement s = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

			ResultSet rs = s.executeQuery(
					"call proiect.search('" + textField.getText() + "','" + textField_1.getText() + "');");

			ResultSetMetaData rsmd = rs.getMetaData();
			int rows = 0;
			while (rs.next())
				rows++;
			if (rows == 0)
				System.out.println("Nu exista date");
			else {
				int contor = -1;
				rs.beforeFirst();
				while (rs.next())
					for (int i = 1; i <= rsmd.getColumnCount(); i++)
						det[++contor] = rs.getObject(i).toString();
			}
			String text = new String();
			for (String z : det)
				if (z != null)
					text = text + " " + z + "\n";

			textArea.setText(text);

		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}

	}
}
