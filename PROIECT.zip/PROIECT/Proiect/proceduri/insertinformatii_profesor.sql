CREATE DEFINER=`root`@`localhost` PROCEDURE `insertinformatii_profesor`( in nume_curs varchar(45), in nume_prof varchar(20), in prenume_prof varchar(20), in nr_min int, in nr_max int, in departament varchar(20),in a varchar(10),in a1 varchar(10),in a2 varchar(10),in a3 varchar(10))
begin
set @ID=( SELECT MAX(informatii_profesor.idcurs) FROM informatii_profesor) + 1;
if @ID IS NULL then
set @ID=1;
end if;
SELECT @ID;
SET @IDprof = (SELECT profesor.idprofesor
               from profesor
			   where profesor.nume = nume_prof
               and profesor.prenume = prenume_prof);
SELECT @IDPROF;
set @idcurs = ( SELECT cursuri.idcurs
                from cursuri
                where cursuri.nume_curs = nume_curs);
SELECT @IDCURS;
insert into proiect.informatii_profesor 
values (@ID, @IDprof, @idcurs, nr_min, nr_max, departament); 
end