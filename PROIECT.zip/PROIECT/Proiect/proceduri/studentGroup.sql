CREATE DEFINER=`root`@`localhost` PROCEDURE `studentGroup`( in nume_stud varchar(20),in prenume_stud varchar(20),in CNP varchar(13), in nume_grup varchar(20))
begin
SET @idstudent1 = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP);
set @idcurs1 = ( SELECT grup_studiu.idcurs
                from grup_studiu
                where grup_studiu.nume = nume_grup );
set @ID=( SELECT MAX(relatii_grup.idrelatii_grup) FROM relatii_grup) + 1;
if @ID IS NULL then
set @ID=1;
end if;
set @idstudent =(select idstudent from inscriere where inscriere.idstudent=@idstudent1 and inscriere.idcurs=@idcurs1);
SET @nrStudActual =(select nr_actual_studenti from grup_studiu where grup_studiu.idcurs=@idcurs1 and grup_studiu.nume = nume_grup);
SET @nrStudMax =(select nr_max_studenti from grup_studiu where grup_studiu.idcurs=@idcurs1  and grup_studiu.nume = nume_grup);
SET @idgrup = (select idgrup_studiu from grup_studiu where grup_studiu.idcurs=@idcurs1  and grup_studiu.nume = nume_grup);
 if @idstudent is not null then
  if(@nrStudActual<@nrStudMax) then
   insert into proiect.relatii_grup values (@ID, @idstudent1, @idgrup);
   update grup_studiu set grup_studiu.nr_actual_studenti= grup_studiu.nr_actual_studenti+1 where grup_studiu.idcurs= @idcurs1  and grup_studiu.nume = nume_grup;
 end if;
 end if;
end