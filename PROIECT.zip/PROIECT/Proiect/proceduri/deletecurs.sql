CREATE DEFINER=`root`@`localhost` PROCEDURE `deletecurs`( in nume_curs varchar(45), in nume_prof varchar(20), in prenume_prof varchar(20), in a varchar(10),in a1 varchar(10),in a2 varchar(10),in a3 varchar(10),in a4 varchar(10),in a5 varchar(10),in a6 varchar(10) )
BEGIN
set @idcurs = ( SELECT cursuri.idcurs
                from cursuri,informatii_profesor,profesor
                where cursuri.nume_curs = nume_curs
                and cursuri.idcurs = informatii_profesor.idcurs
                and informatii_profesor.idprofesor = profesor.idprofesor
                and profesor.nume = nume_prof
                and profesor.prenume = prenume_prof );
DELETE cursuri , activitati 
 FROM cursuri  INNER JOIN activitati 
WHERE cursuri.idcurs= activitati.idcurs 
and cursuri.idcurs = @idcurs;
END