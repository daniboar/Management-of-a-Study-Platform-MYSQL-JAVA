CREATE DEFINER=`root`@`localhost` PROCEDURE `dropCourse`(in curs1 varchar(20), in data_renuntare varchar(10), in idStud int,in a varchar(10),in a1 varchar(10),in a2 varchar(10),in a3 varchar(10),in a4 varchar(10),in a5 varchar(10),in a6 varchar(10))
begin

set @id =(select cursuri.idcurs from cursuri where cursuri.nume_curs= curs1);
update cursuri set cursuri.nr_actual_studenti= cursuri.nr_actual_studenti-1 where cursuri.idcurs = @id;
update inscriere set inscriere.data_renunt=data_renuntare  where inscriere.idstudent = idStud and inscriere.idcurs=@id;
end