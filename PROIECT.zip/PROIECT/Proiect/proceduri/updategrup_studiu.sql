CREATE DEFINER=`root`@`localhost` PROCEDURE `updategrup_studiu`( in nume_init varchar(20), in nume varchar(20), in nr_max_studenti int ,in a varchar(10),in a1 varchar(10),in a2 varchar(10),in a3 varchar(10),in a4 varchar(10),in a5 varchar(10),in a6 varchar(10))
begin
SET @idgrup_studiu = (SELECT grup_studiu.idgrup_studiu
                      from grup_studiu
                      where grup_studiu.nume = nume_init);
if nume IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE grup_studiu 
SET grup_studiu.nume = nume
where grup_studiu.idgrup_studiu = @idgrup_studiu; 
end if;

if nr_max_studenti IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE grup_studiu 
SET grup_studiu.nr_max_studenti = nr_max_studenti
where grup_studiu.idgrup_studiu = @idgrup_studiu; 
end if;
end