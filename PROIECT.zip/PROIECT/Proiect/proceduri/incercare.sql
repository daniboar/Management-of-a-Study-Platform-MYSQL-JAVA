CREATE DEFINER=`root`@`localhost` PROCEDURE `incercare`(in curs1 varchar(20))
begin

select distinct student.idstudent,student.nume, student.prenume, nota_curs,nota_laborator,nota_seminar  from student, inscriere, note_student,curs_nota,seminar_nota,laborator_nota  where 
student.idstudent= inscriere.idstudent and inscriere.idcurs=(select cursuri.idcurs from cursuri where cursuri.nume_curs= curs1)
and student.idstudent=note_student.idstudent and note_student.idlaborator=(select cursuri.idcurs from cursuri where cursuri.nume_curs= curs1) 
and note_student.idseminar = (select cursuri.idcurs from cursuri where cursuri.nume_curs= curs1) 
and note_student.idcurs=(select cursuri.idcurs from cursuri where cursuri.nume_curs= curs1) 
and student.idstudent=laborator_nota.idstudent and student.idstudent=curs_nota.idstudent and student.idstudent=seminar_nota.idstudent;
end