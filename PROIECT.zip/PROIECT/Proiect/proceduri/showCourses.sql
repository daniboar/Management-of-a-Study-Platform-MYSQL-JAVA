CREATE DEFINER=`root`@`localhost` PROCEDURE `showCourses`( in nume1 varchar(20))
begin
select nume_curs, nume from cursuri, profesor, informatii_profesor 
where cursuri.nume_curs=nume1 
and profesor.idprofesor=informatii_profesor.idprofesor 
and cursuri.idcurs=informatii_profesor.idcurs;
end