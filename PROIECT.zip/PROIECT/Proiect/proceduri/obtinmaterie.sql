CREATE DEFINER=`root`@`localhost` PROCEDURE `obtinmaterie`(in CNP varchar(45))
BEGIN
SELECT cursuri.nume_curs FROM cursuri,profesor,informatii_profesor WHERE CNP = profesor.CNP AND profesor.idprofesor = informatii_profesor.idprofesor AND cursuri.idcurs = informatii_profesor.idcurs;
end