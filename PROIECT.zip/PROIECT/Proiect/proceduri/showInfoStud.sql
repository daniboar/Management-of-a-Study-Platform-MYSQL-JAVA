CREATE DEFINER=`root`@`localhost` PROCEDURE `showInfoStud`( in CNP varchar(13))
begin
SELECT *
FROM student
WHERE CNP = student.CNP;
end