CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecursuri`(in nume_prof varchar(20), in prenume_prof varchar(20), in numeinit varchar(45),in nume varchar(45),in descriere varchar(45), in nr_max_stud int,in curspr int, in seminarpr int, in labpr int)
begin

set @idcurs = ( SELECT cursuri.idcurs
                from cursuri,informatii_profesor,profesor
                where cursuri.nume_curs = numeinit
                and cursuri.idcurs = informatii_profesor.idcurs
                and informatii_profesor.idprofesor = profesor.idprofesor
                and profesor.nume = nume_prof
                and profesor.prenume = prenume_prof );

if nume IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE cursuri 
SET cursuri.nume_curs = nume
where cursuri.idcurs = @idcurs; 
end if;

if descriere IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE cursuri 
SET cursuri.descriere = descriere
where cursuri.idcurs = @idcurs; 
end if;

if nr_max_stud IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE cursuri 
SET cursuri.nr_max_studenti = nr_max_stud
where cursuri.idcurs = @idcurs; 
end if;

if curspr IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE activitati 
SET activitati.curspr = curspr
where activitati.idcurs = @idcurs; 
end if;

if seminarpr IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE activitati 
SET activitati.seminarpr = seminarpr
where activitati.idcurs = @idcurs; 
end if;

if labpr IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE activitati 
SET activitati.laborator.pr = labpr
where activitati.idcurs = @idcurs; 
end if;
end