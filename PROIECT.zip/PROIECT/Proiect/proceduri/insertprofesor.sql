CREATE DEFINER=`root`@`localhost` PROCEDURE `insertprofesor`(in cnp varchar(13), in nume varchar(20), in prenume varchar(20), in adresa varchar(10), in telefon varchar(10), in email varchar(20), in iban varchar (16), in nr_contact varchar(10),in a varchar(10),in a1 varchar(10))
begin
set @ID=( SELECT MAX(profesor.idprofesor) FROM profesor) + 1;
if @ID IS NULL then
set @ID=1;
end if;
insert into proiect.profesor 
values (@ID,cnp,nume,prenume,adresa,telefon,email,iban,nr_contact);
end