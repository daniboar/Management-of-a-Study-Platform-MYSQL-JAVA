CREATE DEFINER=`root`@`localhost` PROCEDURE `studentToAGroupActivity`(in nume_stud varchar(20), in prenume_stud varchar(20),in CNP varchar(15), in nume_grup varchar(20), in nume_activ varchar(20))
begin
set @ID=( SELECT MAX(studenti_actvititate.idstudenti_actvititate) FROM studenti_actvititate) + 1;
if @ID IS NULL then
set @ID=1;
end if;
SET @idstud = (SELECT student.idstudent
from student
where student.nume = nume_stud
and student.prenume = prenume_stud
and student.cnp = CNP);
set @idgrup =(select idgrup_studiu from grup_studiu where grup_studiu.nume=nume_grup);
set @idstud1 = (select relatii_grup.idstudent from relatii_grup where relatii_grup.idstudent=@idstud and relatii_grup.idgrup=@idgrup);
set @idactiv= (select idactiv_grup from activ_grup where nume_activ=activ_grup.nume_activ and activ_grup.id_grup_studiu = @idgrup);

if(@idstud1 is not null)then
update activ_grup set activ_grup.nr_actual = activ_grup.nr_actual+1 where nume_activ=activ_grup.nume_activ and activ_grup.id_grup_studiu = @idgrup;
insert into proiect.studenti_actvititate values(@ID, @idstud, @idactiv, @idgrup);
end if;

end