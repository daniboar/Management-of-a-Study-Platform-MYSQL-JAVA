CREATE DEFINER=`root`@`localhost` PROCEDURE `createActivityGroup`(in nume_grup varchar(20), in nume_activ varchar(10),  in data_desf varchar(20), in ora_exp varchar(10), in nr_min int)
begin
set @ID=( SELECT MAX(activ_grup.idactiv_grup) FROM activ_grup) + 1;
if @ID IS NULL then
set @ID=1;
end if;
set @idgrup =( select idgrup_studiu from grup_studiu where grup_studiu.nume=nume_grup);
insert into proiect.activ_grup values (@ID, @idgrup, nr_min, data_desf, ora_exp,0, nume_activ);
end