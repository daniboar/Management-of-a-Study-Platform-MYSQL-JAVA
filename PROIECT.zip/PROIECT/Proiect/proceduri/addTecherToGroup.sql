CREATE DEFINER=`root`@`localhost` PROCEDURE `addTeacherToGroup`(in nume_grup varchar(25), in nume_prof varchar(25), in prenume_prof varchar(20))
begin
set @id=(select idgrup_studiu from grup_studiu where grup_studiu.nume=nume_grup);
set @idProf=(select idprofesor from profesor where profesor.nume=nume_prof and profesor.prenume=prenume_prof );
 update grup_studiu set idprofesor = @idProf where grup_studiu.idgrup_studiu=@id; 
end