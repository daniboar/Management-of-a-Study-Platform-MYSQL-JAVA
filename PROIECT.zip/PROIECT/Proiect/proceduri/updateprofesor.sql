CREATE DEFINER=`root`@`localhost` PROCEDURE `updateprofesor`( in cnp varchar(13), in nume varchar(20), in prenume varchar(20), in adresa varchar(10), in telefon varchar(10), in email varchar(20), in iban varchar (16), in nr_contact varchar(10), in a varchar(10), in a1 varchar(10))
BEGIN
SET @idprof = (SELECT profesor.idprofesor
               from profesor
               where profesor.nume = nume
               and profesor.prenume = prenume
               and  profesor.cnp = cnp);
if cnp IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor 
SET profesor.cnp = cnp
where profesor.idprofesor = @idprof; 
end if;

if nume IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor 
SET profesor.nume = nume
where profesor.idprofesor = @idprof; 
end if;

if prenume is not null then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor 
SET profesor.prenume = prenume
where profesor.idprofesor = @idprof; 
end if;

if(adresa IS NOT null) then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor
SET profesor.adresa = adresa
where profesor.idprofesor = @idprof; 
end if;

if(telefon is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor
SET profesor.telefon = telefon
where profesor.idprofesor = @idprof; 
end if;

if(email is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor
SET profesor.email = email
where profesor.idstudent = @idprof; 
end if;

if(iban is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor 
SET profesor.IBAN = iban
where profesor.idstudent = @idprof; 
end if;

if(nr_contact is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE profesor 
SET profesor.nr_contact = nr_contact
where profesor.idstudent = @idprof; 
end if;
END