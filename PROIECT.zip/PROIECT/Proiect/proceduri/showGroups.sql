CREATE DEFINER=`root`@`localhost` PROCEDURE `showGroups`( in nume_curs varchar(45))
begin
SELECT grup_studiu.nume, grup_studiu.nr_max_studenti,cursuri.nume_curs
from grup_studiu,cursuri
where cursuri.idcurs = (SELECT cursuri.idcurs 
                      FROM cursuri
                      WHERE cursuri.nume_curs = nume_curs )
and grup_studiu.idcurs = cursuri.idcurs;
end