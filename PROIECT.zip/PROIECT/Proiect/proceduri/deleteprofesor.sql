CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteprofesor`(in nume varchar(20), in prenume varchar(20),in cnp varchar(13), in a varchar(10),in a1 varchar(10),in a2 varchar(10),in a3 varchar(10),in a4 varchar(10),in a5 varchar(10),in a6 varchar(10))
BEGIN
SET @idprof = (SELECT profesor.idprofesor
               from profesor
               where profesor.nume = nume
               and profesor.prenume = prenume
               and  profesor.cnp = CNP);
DELETE  
FROM profesor
WHERE profesor.idprofesor = @idprof;
END