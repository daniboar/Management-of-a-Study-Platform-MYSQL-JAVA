CREATE DEFINER=`root`@`localhost` PROCEDURE `addProcente`( in nume varchar(45),in curspr int, in seminarpr int, in labpr int)
begin
set @id =(select activitati.idcurs from activitati, cursuri where cursuri.nume_curs=nume and cursuri.idcurs=activitati.idcurs);
update activitati set activitati.laboratorpr=labpr where activitati.idcurs=@id;
update activitati set activitati.seminarpr=seminarpr where activitati.idcurs=@id;
update activitati set activitati.curspr=curspr where activitati.idcurs=@id;
end