CREATE DEFINER=`root`@`localhost` PROCEDURE `showInfoAdmin`( in CNP varchar(13))
begin
SELECT *
FROM administrator
WHERE CNP = administrator.CNP;
end