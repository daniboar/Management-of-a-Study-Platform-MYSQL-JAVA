CREATE DEFINER=`root`@`localhost` PROCEDURE `showNotes`(in nume_stud varchar(20), in prenume_stud varchar(20), in CNP varchar(13) )
begin
SET @idstud = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP);
select distinct  nume_curs, nota_curs, nota_laborator, nota_seminar 
from cursuri, curs_nota, laborator_nota, seminar_nota, student, note_student, inscriere 
where @idStud=student.idstudent and student.idstudent = note_student.idstudent 
and student.idstudent =  inscriere.idstudent 
and note_student.idlaborator=laborator_nota.idcurs
and note_student.idcurs=curs_nota.idcurs 
and note_student.idseminar=seminar_nota.idcurs
and note_student.idcurs=cursuri.idcurs;
end