CREATE DEFINER=`root`@`localhost` PROCEDURE `insertstudent`( in cnp varchar(13), in nume varchar(20), in prenume varchar(20), in adresa varchar(10), in telefon varchar(10), in email varchar(20), in iban varchar (16), in nr_contact varchar(10), in anstudiu int, in nrore int)
begin
set @ID=( SELECT MAX(student.idstudent) FROM student) + 1;
if @ID IS NULL then
set @ID=1;
end if;
insert into proiect.student 
values (@ID,cnp,nume,prenume,adresa,telefon,email,iban,nr_contact, anstudiu, nrore);
end