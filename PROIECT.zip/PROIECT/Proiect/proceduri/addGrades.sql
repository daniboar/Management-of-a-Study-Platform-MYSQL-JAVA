CREATE DEFINER=`root`@`localhost` PROCEDURE `addGrades`(in nume_stud varchar(20), in prenume_stud varchar(20), in CNP varchar(13), in nume_curs varchar(45),in nume_prof varchar(20), in prenume_prof varchar(20), in notas int, in notal int, in notac int)
begin
SET @idstudent = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP);
SELECT @idstudent;
set @idcurs = ( SELECT cursuri.idcurs
                from cursuri,informatii_profesor,profesor
                where cursuri.nume_curs = nume_curs
                and cursuri.idcurs = informatii_profesor.idcurs
                and informatii_profesor.idprofesor = profesor.idprofesor
                and profesor.nume = nume_prof
                and profesor.prenume = prenume_prof );


set @ordineNote=( SELECT MAX(note_student.idordine) FROM note_student) + 1;
if @ordineNote IS NULL then
set @ordineNote =1;

SET @idlaborator = ( SELECT MAX(laborator_nota.idlaborator_nota) FROM laborator_nota) + 1;
if @idlaborator IS NULL then
set @idlaborator=1;
end if; 


SET @idseminar = ( SELECT MAX(seminar_nota.idseminar_nota) FROM seminar_nota) + 1;
if @idseminar IS NULL then
set @idseminar=1;
end if; 


end if;
SET SQL_SAFE_UPDATES=0;
SET @data =(select inscriere.data_inscriere from inscriere where inscriere.idstudent=@idstudent and inscriere.idcurs=@idcurs);
set @data1 =(select inscriere.data_renunt from inscriere where inscriere.idstudent=@idstudent and inscriere.idcurs=@idcurs);
	if @data IS NOT NULL then
    if @data1 is NULL then
   
     insert into proiect.laborator_nota (idlaborator_nota, idcurs) 
		values (@ordineNote,@idcurs);
	insert into proiect.seminar_nota (idseminar_nota, idcurs) 
		values (@ordineNote, @idcurs);
		insert into proiect.curs_nota (idcurs_nota, idcurs)
		values (@ordineNote,@idcurs);
        
         insert into proiect.note_student
    values (@idstudent, @idcurs, @idcurs, @idcurs, @ordineNote);
	
       
    update seminar_nota set  seminar_nota.sem = @idseminar where seminar_nota.idseminar_nota=@ordineNote;
	update curs_nota set  curs_nota.curs = @idcurs where curs_nota.idcurs_nota=@ordineNote;
	update laborator_nota set  laborator_nota.lab = @idlaborator where laborator_nota.idlaborator_nota=@ordineNote;
    
    update seminar_nota set  seminar_nota.nota_seminar = notas where seminar_nota.sem=@idseminar and seminar_nota.idseminar_nota=@ordineNote; 
	update curs_nota set  curs_nota.nota_curs = notac where curs_nota.curs=@idcurs and curs_nota.idcurs_nota=@ordineNote;
	update laborator_nota set  laborator_nota.nota_laborator = notal where laborator_nota.lab=@idlaborator and laborator_nota.idlaborator_nota=@ordineNote;
    
    
    
    update seminar_nota set  seminar_nota.idstudent = @idstudent where seminar_nota.sem=@idseminar and seminar_nota.idseminar_nota=@ordineNote; 
	update curs_nota set  curs_nota.idstudent = @idstudent where curs_nota.curs=@idcurs and curs_nota.idcurs_nota=@ordineNote;
	update laborator_nota set  laborator_nota.idstudent = @idstudent where laborator_nota.lab=@idlaborator and laborator_nota.idlaborator_nota=@ordineNote;
    end if;
    end if;
end