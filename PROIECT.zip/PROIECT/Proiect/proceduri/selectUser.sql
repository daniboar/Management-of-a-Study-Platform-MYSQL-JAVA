CREATE DEFINER=`root`@`localhost` PROCEDURE `selectUser`(IN tblName1 varchar (50), in nume varchar(45), in prenume varchar(20), in cnp varchar(15))
begin
  SET @ddl = CONCAT(' SELECT * FROM ', tblName1, ' where ' , tblName1, '.CNP="', cnp, '" and ',  tblName1,'.nume="', nume, '" and ',  tblName1,'.prenume="', prenume,'";');
  PREPARE STMT FROM @ddl;
  EXECUTE STMT;
END