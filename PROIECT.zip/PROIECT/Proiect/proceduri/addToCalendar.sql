CREATE DEFINER=`root`@`localhost` PROCEDURE `addToCalendar`(in nume_curs varchar(10), in data_sem date, in data1_sem date, in data_lab date, in data1_lab date, in data_curs date, in data1_curs date)
begin
set @idcurs = ( SELECT cursuri.idcurs
                from cursuri
                where cursuri.nume_curs = nume_curs );
insert into proiect.calendar values(@idcurs, data_curs, data1_curs, data_lab, data1_lab, data_sem, data1_sem);

end