CREATE DEFINER=`root`@`localhost` PROCEDURE `membersGroup`( in nume_grup varchar(20))
BEGIN
set @idgrup = (SELECT idgrup_studiu from grup_studiu where grup_studiu.nume = nume_grup );
select student.nume, student.prenume
from student,relatii_grup
where student.idstudent = relatii_grup.idstudent
and relatii_grup.idgrup = @idgrup;
END