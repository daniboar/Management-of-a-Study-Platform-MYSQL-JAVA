CREATE DEFINER=`root`@`localhost` PROCEDURE `showActivitati`( in nume_stud varchar(20), in prenume_stud varchar(20), in CNP_stud varchar(13))
begin
SET @idstudent1 = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP_stud);

select nume_curs from cursuri, inscriere where inscriere.idstudent=@idstudent1 and cursuri.idcurs=inscriere.idcurs;
end