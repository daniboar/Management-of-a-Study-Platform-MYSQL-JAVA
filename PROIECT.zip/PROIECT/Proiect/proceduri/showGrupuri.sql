CREATE DEFINER=`root`@`localhost` PROCEDURE `showGrupuri`( in nume_stud varchar(20), in prenume_stud varchar(20), in CNP_stud varchar(13))
begin
SET @idstudent1 = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP_stud);

select nume from grup_studiu, relatii_grup where relatii_grup.idstudent=@idstudent1 and grup_studiu.idgrup_studiu=relatii_grup.idgrup;
end