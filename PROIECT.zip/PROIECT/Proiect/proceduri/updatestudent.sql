CREATE DEFINER=`root`@`localhost` PROCEDURE `updatestudent`(in cnp varchar(13), in nume varchar(20), in prenume varchar(20), in adresa varchar(10), in telefon varchar(10), in email varchar(20), in iban varchar (16), in nr_contact varchar(10), in a varchar(10), in a1 varchar(10))
BEGIN
SET @idstud = (SELECT student.idstudent
               from student
               where student.nume = nume 
               and student.prenume = prenume
               and  student.cnp = cnp);
if cnp IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.cnp = cnp
where student.idstudent = @idstud; 
end if;

if nume IS NOT NULL then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.nume = nume
where student.idstudent = @idstud; 
end if;

if prenume is not null then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.prenume = prenume
where student.idstudent = @idstud; 
end if;

if(adresa IS NOT null) then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.adresa = adresa
where student.idstudent = @idstud; 
end if;

if(telefon is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE student
SET student.telefon = telefon
where student.idstudent = @idstud; 
end if;

if(email is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE student
SET student.email = email
where student.idstudent = @idstud; 
end if;

if(iban is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.IBAN = iban
where student.idstudent = @idstud; 
end if;

if(nr_contact is not null) then
SET SQL_SAFE_UPDATES=0;
UPDATE student 
SET student.nr_contact = nr_contact
where student.idstudent = @idstud; 
end if;
END