CREATE DEFINER=`root`@`localhost` PROCEDURE `deletegrup_studiu`( in nume_grup varchar(45), in nume_curs varchar(45), in nume_prof varchar(20), in prenume_prof varchar(20),in a varchar(10),in a2 varchar(10),in a3 varchar(10),in a4 varchar(10),in a5 varchar(10),in a6 varchar(10))
begin
set @idcurs = ( SELECT cursuri.idcurs
                from cursuri,informatii_profesor,profesor
                where cursuri.nume_curs = nume_curs
                and cursuri.idcurs = informatii_profesor.idcurs
                and informatii_profesor.idprofesor = profesor.idprofesor
                and profesor.nume = nume_prof
                and profesor.prenume = prenume_prof );
SET @idgrup_studiu = (SELECT grup_studiu.idgrup_studiu
                      from grup_studiu
                      where grup_studiu.nume = nume_grup);
DELETE grup_studiu
from grup_studiu
where grup_studiu.idgrup_studiu = idgrup_studiu;
end