CREATE DEFINER=`root`@`localhost` PROCEDURE `showInfoSuperAdmin`( in CNP varchar(13))
begin
SELECT *
FROM super_administrator
WHERE CNP = super_administrator.CNP;
end