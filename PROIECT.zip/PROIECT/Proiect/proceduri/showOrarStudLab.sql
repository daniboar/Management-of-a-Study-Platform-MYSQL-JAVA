CREATE DEFINER=`root`@`localhost` PROCEDURE `showOrarStudLab`(in nume varchar(20), in prenume varchar(20), in cnp varchar(20), in zi varchar(10))
begin
SELECT orar_student.ora_lab, cursuri.nume_curs
FROM orar_student,cursuri
WHERE orar_student.idstudent = (SELECT student.idstudent from student where student.nume = nume and student.prenume = prenume and  student.cnp = cnp)
AND orar_student.zi_lab = zi
AND cursuri.idcurs = orar_student.idcurs;
end