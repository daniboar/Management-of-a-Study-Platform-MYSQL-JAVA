CREATE DEFINER=`root`@`localhost` PROCEDURE `dropStudyGroup`(in nume_stud varchar(20),in prenume_stud varchar(20),in CNP varchar(13), in nume_grup varchar(20))
begin
SET @idstudent = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP);
set @idcurs = ( SELECT grup_studiu.idcurs
                from grup_studiu
                where grup_studiu.nume = nume_grup );
set @idgrup = (SELECT grup_studiu.idgrup_studiu
               from grup_studiu
               where grup_studiu.nume = nume_grup );
set @nr_actual = (select grup_studiu.nr_actual_studenti
                 from grup_studiu
				 where grup_studiu.nume = nume_grup );
set @idrelatii = (SELECT relatii_grup.idrelatii_grup
                  from relatii_grup
                  where relatii_grup.idstudent = @idstudent
                  and relatii_grup.idgrup = @idgrup);
if @idrelatii is not null then
if @idstudent is not null then
update grup_studiu set grup_studiu.nr_actual_studenti = @nr_actual-1 where grup_studiu.idcurs= @idcurs  and grup_studiu.nume = nume_grup;
delete relatii_grup from relatii_grup where relatii_grup.idgrup = @idgrup and relatii_grup.idstudent = @idstudent;
end if;
 end if;
end