CREATE DEFINER=`root`@`localhost` PROCEDURE `insertcursuri`( in nume varchar(45),in descriere varchar(45), in nr_max_stud int, in zi_curs varchar(20), in zi_seminar varchar(20), in zi_lab varchar(20), in ora_curs int , in ora_lab int, in ora_sem int, in a varchar(10))
begin
set @ID=( SELECT MAX(cursuri.idcurs) FROM cursuri) + 1;
if @ID IS NULL then
set @ID=1;
end if;
INSERT INTO `proiect`.`cursuri` (`idcurs`, `nume_curs`,`descriere`,`nr_max_studenti`,`nr_actual_studenti`) 
VALUES (@ID, nume, descriere, nr_max_stud,'0');
insert into activitati (idcurs, zi_curs, zi_lab, zi_seminar, ora_curs, ora_lab, ora_sem) 
values (@ID, zi_curs, zi_lab, zi_seminar, ora_curs, ora_lab, ora_sem);
end