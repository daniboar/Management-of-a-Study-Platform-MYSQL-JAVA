CREATE DEFINER=`root`@`localhost` PROCEDURE `studentRegistration`( in nume_stud varchar(20), in prenume_stud varchar(20), in CNP_stud varchar(13), in nume_prof varchar(20),in prenume_prof varchar(20), in nume_curs varchar(45))
begin
SET @idstudent1 = (SELECT student.idstudent
               from student
               where student.nume = nume_stud 
               and student.prenume = prenume_stud
               and  student.cnp = CNP_stud);
SET @idprofesor1 = (SELECT profesor.idprofesor
               from cursuri,informatii_profesor,profesor
               where profesor.nume = nume_prof
               and profesor.prenume = prenume_prof
               and cursuri.idcurs = informatii_profesor.idcurs
			   and informatii_profesor.idprofesor = profesor.idprofesor
               and cursuri.nume_curs = nume_curs);
set @idcurs1 = ( SELECT cursuri.idcurs
                from cursuri,informatii_profesor,profesor
                where cursuri.nume_curs = nume_curs
                and cursuri.idcurs = informatii_profesor.idcurs
                and informatii_profesor.idprofesor = profesor.idprofesor
                and profesor.nume = nume_prof
                and profesor.prenume = prenume_prof );
set @data_inscriere1 = curdate();
set @ID=( SELECT MAX(orar_student.idorar_student) FROM orar_student) + 1;
if @ID IS NULL then
set @ID=1;
end if;

set @ID1=( SELECT MAX(inscriere.idinscriere) FROM inscriere) + 1;
if @ID1 IS NULL then
set @ID1=1;
end if;

SET @nrStudActual =(select nr_actual_studenti from cursuri where cursuri.idcurs=@idcurs1);
SET @nrStudMax =(select nr_max_studenti from cursuri where cursuri.idcurs=@idcurs1);

set @ziualab= (select zi_lab from activitati  where activitati.idcurs=@idcurs1);
set @ziuacurs= (select zi_curs from activitati where activitati.idcurs=@idcurs1);
set @ziuasem= (select zi_seminar from activitati where activitati.idcurs=@idcurs1);

set @oracurs= (select ora_curs from activitati where activitati.idcurs=@idcurs1);
set @oralab= (select ora_lab from activitati where activitati.idcurs=@idcurs1);
set @orasem= (select ora_sem from activitati where activitati.idcurs=@idcurs1);

-- set @ziualab1= (select zi_lab from orar_student  where   orar_student.idstudent=idstudent1 and @ziualab=orar_student.zi_lab and @oralab<>orar_student.ora_lab);
-- set @ziuacurs1= (select zi_curs from orar_student where      orar_student.idstudent=idstudent1 and @ziuacurs=orar_student.zi_curs and @oracurs<>orar_student.ora_curs);
-- set @ziuasem1= (select zi_sem from orar_student where   orar_student.idstudent=idstudent1 and  @ziuasem=orar_student.zi_sem and @orasem<>orar_student.ora_sem);
 set @oracurs1= NULL;
set @oralab1= NULL;
set @orasem1= NULL;

set @idstud =  (select count(orar_student.idstudent) from orar_student where orar_student.idstudent= @idstudent1);
(select orar_student.idstudent from orar_student where orar_student.idstudent= @idstudent1);
if(@idstud >0 ) then
if(@ziuacurs="Luni")then
set @oracurs1= (select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Luni" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Luni" and  @oracurs=orar_student.ora_sem) or (orar_student.zi_lab="Luni" and  @oracurs=orar_student.ora_lab)));
end if;
-- (select ora_curs from orar_student where  orar_student.idstudent=idstudent1 and (orar_student.zi_curs="Luni" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Luni" and @orasem=orar_student.ora_curs) or (orar_student.zi_lab="Luni" and @oralab=orar_student.ora_curs));
 
 if(@ziuacurs="Marti")then
set @oracurs1= (select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Marti" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Marti" and @oracurs=orar_student.ora_sem) or (orar_student.zi_lab="Marti" and @oracurs=orar_student.ora_lab)));
end if;
(select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Marti" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Marti" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Marti" and @oralab=orar_student.ora_lab)));
if(@ziuacurs="Miercuri")then
set @oracurs1= (select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Miercuri" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Miercuri" and  @oracurs=orar_student.ora_sem) or (orar_student.zi_lab="Miercuri" and @oralab=orar_student.ora_lab)));
end if;

if(@ziuacurs="Joi")then
set @oracurs1= (select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Joi" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Joi" and  @oracurs=orar_student.ora_sem) or (orar_student.zi_lab="Joi" and  @oracurs=orar_student.ora_lab)));
end if;

if(@ziuacurs="Vineri")then
set @oracurs1= (select ora_curs from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Vineri" and @oracurs=orar_student.ora_curs) or (orar_student.zi_sem="Vineri" and  @oracurs=orar_student.ora_sem) or (orar_student.zi_lab="Vineri" and  @oracurs=orar_student.ora_lab)));
end if;

--
if(@ziualab="Luni")then
set @oralab1= (select ora_lab from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Luni" and @oralab=orar_student.ora_curs) or (orar_student.zi_sem="Luni" and @oralab=orar_student.ora_sem) or (orar_student.zi_lab="Luni" and @oralab=orar_student.ora_lab)));
end if;
 
 if(@ziualab="Marti")then
set @oralab1= (select ora_lab from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Marti" and @oralab=orar_student.ora_curs) or (orar_student.zi_sem="Marti" and @oralab=orar_student.ora_sem) or (orar_student.zi_lab="Marti" and @oralab=orar_student.ora_lab)));
end if;

if(@ziualab="Miercuri")then
set @oralab1= (select ora_lab from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Miercuri" and @oralabs=orar_student.ora_curs) or (orar_student.zi_sem="Miercuri" and @oralab=orar_student.ora_sem) or (orar_student.zi_lab="Miercuri" and @oralab=orar_student.ora_lab)));
end if;

if(@ziualab="Joi")then
set @oralab1= (select ora_lab  from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Joi" and @oralab=orar_student.ora_curs) or (orar_student.zi_sem="Joi" and @oralab=orar_student.ora_sem) or (orar_student.zi_lab="Joi" and @oralab=orar_student.ora_lab)));
end if;

if(@ziualab="Vineri")then
set @oralab1= (select ora_lab  from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Vineri" and @oralab=orar_student.ora_curs) or (orar_student.zi_sem="Vineri" and @oralab=orar_student.ora_sem) or (orar_student.zi_lab="Vineri" and @oralab=orar_student.ora_lab)));
end if;
-- (select ora_lab  from orar_student where  orar_student.idstudent=idstudent1 and (orar_student.zi_curs="Vineri" and @oracurs=orar_student.ora_lab) or (orar_student.zi_sem="Vineri" and @orasem=orar_student.ora_lab) or (orar_student.zi_lab="Vineri" and @oralab=orar_student.ora_lab));


if(@ziuasem="Luni")then
set @orasem1= (select ora_sem from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Luni" and @orasem=orar_student.ora_curs) or (orar_student.zi_sem="Luni" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Luni" and @orasem=orar_student.ora_lab)));
end if;
 
 if(@ziuasem="Marti")then
set @orasem1= (select ora_sem from orar_student where orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Marti" and @orasem=orar_student.ora_curs) or (orar_student.zi_sem="Marti" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Marti" and @orasem=orar_student.ora_lab)));
end if;
-- select ora_sem from orar_student where  orar_student.idstudent=idstudent1 and (orar_student.zi_sem="Marti" and @orasem=orar_student.ora_sem);
if(@ziuasem="Miercuri")then
set @orasem1= (select ora_sem from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Miercuri" and @orasem=orar_student.ora_curs) or (orar_student.zi_sem="Miercuri" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Miercuri" and @oralab=orar_student.ora_lab)));
end if;

if(@ziuasem="Joi")then
set @orasem1= (select ora_sem  from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Joi" and @orasem=orar_student.ora_curs) or (orar_student.zi_sem="Joi" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Joi" and @orasem=orar_student.ora_lab)));
end if;

if(@ziuasem="Vineri")then
set @orasem1= (select ora_sem  from orar_student where  orar_student.idstudent=@idstudent1 and ((orar_student.zi_curs="Vineri" and @orasem=orar_student.ora_curs) or (orar_student.zi_sem="Vineri" and @orasem=orar_student.ora_sem) or (orar_student.zi_lab="Vineri" and @orasem=orar_student.ora_lab)));
end if;
--
end if;

 
if((@oracurs1 is null) and (@orasem1 is  null) and (@oralab1 is null)) then
  if(@nrStudActual<@nrStudMax) then
insert into proiect.inscriere (idinscriere, idstudent, idprofesor,idcurs,data_inscriere) 
values  (@ID1, @idstudent1, @idprofesor1,@idcurs1,@data_inscriere1);
update cursuri set cursuri.nr_actual_studenti= cursuri.nr_actual_studenti+1 where cursuri.idcurs= @idcurs1;
insert into proiect.orar_student values(@ID, @idstudent1, @idcurs1, @ziuacurs, @ziualab, @ziuasem, @oracurs, @oralab, @orasem);
end if;
end if;

end