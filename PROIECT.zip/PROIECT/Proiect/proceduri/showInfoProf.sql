CREATE DEFINER=`root`@`localhost` PROCEDURE `showInfoProf`( in CNP varchar(13))
begin
SELECT *
FROM profesor
WHERE CNP = profesor.CNP;
end