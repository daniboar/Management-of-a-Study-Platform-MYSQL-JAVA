CREATE DEFINER=`root`@`localhost` PROCEDURE `showOrarProfCurs`(in nume varchar(20), in prenume varchar(20), in cnp varchar(20), in zi varchar(10))
begin
select ora_curs from activitati join (select idcurs from informatii_profesor where informatii_profesor.idprofesor=(SELECT profesor.idprofesor
               from profesor
               where profesor.nume = nume 
               and profesor.prenume = prenume
               and  profesor.cnp = cnp) ) as cursuri on activitati.idcurs=cursuri.idcurs where activitati.zi_curs=zi;
end